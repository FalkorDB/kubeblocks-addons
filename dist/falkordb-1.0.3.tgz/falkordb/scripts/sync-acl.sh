#!/bin/sh
service_port=${SERVICE_PORT:-6379}
redis_base_cmd="redis-cli $REDIS_CLI_TLS_CMD -p $service_port -a $REDIS_DEFAULT_PASSWORD"
if [ -z "$REDIS_DEFAULT_PASSWORD" ]; then
   redis_base_cmd="redis-cli $REDIS_CLI_TLS_CMD -p $service_port"
fi

is_ok=false
acl_list=""
# 1. get acl list from other pods
for pod_fqdn in $(echo "$REDIS_POD_FQDN_LIST" | tr ',' ' '); do
    if [ "$pod_fqdn" = "$KB_JOIN_MEMBER_POD_FQDN" ]; then
        continue
    fi
    acl_list=$($redis_base_cmd -h "$pod_fqdn" ACL LIST)
    if [ $? -eq 0 ]; then
        is_ok=true
        break
    fi
done

if [ "$is_ok" = "false" ]; then
    echo "Failed to get ACL LIST from other pods" >&2
    exit 1
fi

if [ -z "$acl_list" ]; then
    echo "No ACL rules found in other pods, skip synchronization" >&2
    exit 0
fi

set -e
# 2. apply acl list to current pod
while IFS= read -r user_rule; do
    [ -z "$user_rule" ] && continue

    username=$(printf '%s' "$user_rule" | sed -n 's/^user[[:space:]]\{1,\}\([^[:space:]]\{1,\}\).*/\1/p')
    if [ -z "$username" ]; then
      # skip invalid user rule
      continue
    fi

    if [ "$username" = "default" ]; then
        continue
    fi
    rule_part="${user_rule#user $username }"
    $redis_base_cmd -h $KB_JOIN_MEMBER_POD_FQDN ACL SETUSER "$username" $rule_part >&2
done << _ACL_LIST_EOF_
$acl_list
_ACL_LIST_EOF_

$redis_base_cmd -h $KB_JOIN_MEMBER_POD_FQDN ACL save >&2
