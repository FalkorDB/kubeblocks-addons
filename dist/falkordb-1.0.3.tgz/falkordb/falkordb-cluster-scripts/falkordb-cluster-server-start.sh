#!/bin/sh

# shellcheck disable=SC2153
# shellcheck disable=SC2207
# shellcheck disable=SC2034
# shellcheck disable=SC1090

# This is magic for shellspec ut framework. "test" is a `test [expression]` well known as a shell command.
# Normally test without [expression] returns false. It means that __() { :; }
# function is defined if this script runs directly.
#
# shellspec overrides the test command and returns true *once*. It means that
# __() function defined internally by shellspec is called.
#
# In other words. If not in test mode, __ is just a comment. If test mode, __
# is a interception point.
# you should set ut_mode="true" when you want to run the script in shellspec file.
ut_mode="false"
test || __() {
  # when running in non-unit test mode, set the options "set -ex".
  set -ex;
}

service_port=${SERVICE_PORT:-6379}
cluster_bus_port=16379
redis_template_conf="/etc/conf/redis.conf"
redis_real_conf="/etc/redis/redis.conf"
redis_extra_conf="/etc/conf/extra/redis.conf"
redis_acl_file="/data/users.acl"
redis_acl_file_bak="/data/users.acl.bak"
retry_times=3
check_ready_times=30
retry_delay_second=2

# variables for scale out replica (pipe-separated strings)
current_comp_primary_node=""
current_comp_primary_fail_node=""
current_comp_other_nodes=""
other_comp_primary_nodes=""
other_comp_primary_fail_nodes=""
other_comp_other_nodes=""


init_environment(){
  if [ -z "${CURRENT_SHARD_ADVERTISED_PORT}" ]; then
    CURRENT_SHARD_ADVERTISED_PORT="${CURRENT_SHARD_LB_ADVERTISED_PORT}"
  fi
  if [ -z "${CURRENT_SHARD_ADVERTISED_BUS_PORT}" ]; then
    CURRENT_SHARD_ADVERTISED_BUS_PORT="${CURRENT_SHARD_LB_ADVERTISED_BUS_PORT}"
  fi
}

extract_lb_host_by_svc_name() {
  local svc_name="$1"
  for lb_composed_name in $(printf '%s\n' "$CURRENT_SHARD_LB_ADVERTISED_HOST" | tr ',' ' '); do
    case "$lb_composed_name" in
      *:*)
        if [ "${lb_composed_name%:*}" = "$svc_name" ]; then
          echo "${lb_composed_name#*:}"
          break
        fi
        ;;
      *)
        break
        ;;
    esac
  done
}

load_redis_cluster_common_utils() {
  # the common.sh and falkordb-cluster-common.sh scripts are defined in the falkordb-cluster-scripts-template configmap
  # and are mounted to the same path which defined in the cmpd.spec.scripts
  kblib_common_library_file="/scripts/common.sh"
  redis_cluster_common_library_file="/scripts/falkordb-cluster-common.sh"
  . "${kblib_common_library_file}"
  . "${redis_cluster_common_library_file}"
}

check_and_meet_node() {
  local source_endpoint="$1"
  local source_port="$2"
  local target_endpoint="$3"
  local target_port="$4"
  local target_bus_port="$5"

  # Check for invalid port numbers and exit immediately if found
  if [ "$target_port" -eq 0 ] || [ "$target_bus_port" -eq 0 ]; then
    echo "Error: target_port ($target_port) or target_bus_port ($target_bus_port) is 0. Exiting..."
    shutdown_redis_server "$service_port"
    exit 1
  fi

  while true; do
    # Get current announce IP from the target node
    current_announce_ip=$(get_cluster_announce_ip "$target_endpoint" "$target_port")
    echo "target: $target_endpoint:$target_port, current_announce_ip: $current_announce_ip"

    # If current_announce_ip is empty, retry
    if is_empty "$current_announce_ip"; then
      echo "Error: current_announce_ip is empty"
      sleep_when_ut_mode_false 3
      continue
    fi

    # send cluster meet command to the primary node
    if send_cluster_meet_with_retry "$source_endpoint" "$source_port" "$current_announce_ip" "$target_port" "$target_bus_port"; then
      echo "Meet the node $target_endpoint successfully with new announce ip $current_announce_ip..."
      break
    else
      echo "Failed to meet the node $target_endpoint" >&2
      shutdown_redis_server "$service_port"
      exit 1
    fi
  done
}

check_and_meet_other_primary_nodes() {
  local current_primary_endpoint="$1"
  local current_primary_port="$2"
  _meet_list="$other_comp_primary_nodes"
  if [ -n "$other_comp_primary_fail_nodes" ]; then
    _meet_list="${_meet_list:+${_meet_list}|}${other_comp_primary_fail_nodes}"
  fi
  if [ -z "$_meet_list" ]; then
    echo "meet_other_comp_primary_nodes is empty, skip check_and_meet_other_primary_nodes"
    return
  fi

  # node_info value format: cluster_announce_ip#pod_fqdn#endpoint:port@bus_port
  for node_info in $(printf '%s' "$_meet_list" | tr '|' '\n'); do
    node_endpoint_with_port=$(echo "$node_info" | awk -F '@' '{print $1}' | awk -F '#' '{print $3}')
    node_endpoint=$(echo "$node_endpoint_with_port" | awk -F ':' '{print $1}')
    node_port=$(echo "$node_endpoint_with_port" | awk -F ':' '{print $2}')
    node_bus_port=$(echo "$node_info" | awk -F '@' '{print $2}')

    check_and_meet_node "$current_primary_endpoint" "$current_primary_port" "$node_endpoint" "$node_port" "$node_bus_port"
    sleep_when_ut_mode_false 3
  done
}

check_and_meet_current_primary_node() {
  local primary_node_endpoint="$1"
  local primary_node_port="$2"
  local primary_bus_port="$3"

  check_and_meet_node "127.0.0.1" "$service_port" "$primary_node_endpoint" "$primary_node_port" "$primary_bus_port"
}

# get the current component nodes for scale out replica
get_current_comp_nodes_for_scale_out_replica() {
  local cluster_node="$1"
  local cluster_node_port="$2"
  cluster_nodes_info=$(get_cluster_nodes_info "$cluster_node" "$cluster_node_port")
  status=$?
  if [ $status -ne 0 ]; then
    echo "Failed to get cluster nodes info in get_current_comp_nodes_for_scale_out_replica: $cluster_nodes_info" >&2
    return 1
  fi

  # if the cluster_nodes_info contains only one line, it means that the cluster not be initialized
  shard_count=$(echo "${ALL_SHARDS_COMPONENT_SHORT_NAMES}" | tr ',' '\n' | wc -l)
  if [ "$(echo "$cluster_nodes_info" | wc -l)" -lt ${shard_count} ]; then
    echo "Cluster nodes info contains less than ${shard_count} nodes, returning..."
    return
  fi

  # determine network mode
  local network_mode="default"
  if ! is_empty "$CURRENT_SHARD_ADVERTISED_PORT"; then
    network_mode="advertised_svc"
  elif ! is_empty "$REDIS_CLUSTER_ALL_SHARDS_HOST_NETWORK_PORT"; then
    network_mode="host_network"
  fi

  parse_node_line_info() {
    # the output of line is like:
    # 1. using the pod fqdn as the nodeAddr
    # 4958e6dca033cd1b321922508553fab869a29d 10.42.0.227:6379@16379,falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc.cluster.local master - 0 1711958289570 4 connected 0-1364 5461-6826 10923-12287
    # 2. using the nodeport or lb ip as the nodeAddr
    # 4958e6dca033cd1b321922508553fab869a29d 172.10.0.1:31000@31888,falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc.cluster.local master master - 0 1711958289570 4 connected 0-1364 5461-6826 10923-12287
    # 3. using the host network ip as the nodeAddr
    # 4958e6dca033cd1b321922508553fab869a29d 172.10.0.1:1050@1051,falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc.cluster.local master - 0 1711958289570 4 connected 0-1364 5461-6826 10923-12287
    local line="$1"

    local node_ip_port_fields
    # 10.42.0.227:6379@16379,falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc
    node_ip_port_fields=$(echo "$line" | awk '{print $2}')

    local node_announce_ip_port
    # ip:port without bus port
    node_announce_ip_port=$(echo "$node_ip_port_fields" | awk -F '@' '{print $1}')

    local node_announce_ip
    node_announce_ip=$(echo "$node_announce_ip_port" | cut -d':' -f1)

    local node_port
    node_port=$(echo "$node_announce_ip_port" | cut -d':' -f2)

    local node_bus_port
    node_bus_port=$(echo "$node_ip_port_fields" | awk -F '@' '{print $2}' | awk -F ',' '{print $1}')

    local node_fqdn
    # falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc.cluster.local
    node_fqdn=$(echo "$line" | awk '{print $2}' | awk -F ',' '{print $2}')

    local node_role
    node_role=$(echo "$line" | awk '{print $3}')

    printf "%s %s %s %s %s" "$node_announce_ip" "$node_fqdn" "$node_port" "$node_bus_port" "$node_role"
  }

  build_node_entry() {
    local mode="$1"
    local announce_ip="$2"
    local fqdn="$3"
    local port="$4"
    local bus_port="$5"

    case "$mode" in
      "advertised_svc")
        # example format using nodeport: 172.10.0.1#falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc#172.10.0.1:31000@31888
        echo "$announce_ip#$fqdn#$announce_ip:$port@$bus_port"
        ;;
      "host_network")
        # example format using host network: 172.10.0.1#falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc#172.10.0.1:1050@1051
        echo "$announce_ip#$fqdn#$announce_ip:$port@$bus_port"
        ;;
      *)
        # example format using pod fqdn: 10.42.0.227#falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc#falkordb-shard-sxj-0.falkordb-shard-sxj-headless.default.svc:6379@16379
        echo "$announce_ip#$fqdn#$fqdn:$port@$bus_port"
        ;;
    esac
  }

  # categorize node into appropriate array
  categorize_node() {
    local node_entry="$1"
    local node_fqdn="$2"
    local node_role="$3"

    if contains "$node_fqdn" "$CURRENT_SHARD_COMPONENT_NAME"; then
      if contains "$node_role" "master"; then
        if contains "$node_role" "fail"; then
          current_comp_primary_fail_node="${current_comp_primary_fail_node:+${current_comp_primary_fail_node}|}${node_entry}"
        else
          current_comp_primary_node="${current_comp_primary_node:+${current_comp_primary_node}|}${node_entry}"
        fi
      else
        current_comp_other_nodes="${current_comp_other_nodes:+${current_comp_other_nodes}|}${node_entry}"
      fi
    else
      if contains "$node_role" "master"; then
        if contains "$node_role" "fail"; then
          other_comp_primary_fail_nodes="${other_comp_primary_fail_nodes:+${other_comp_primary_fail_nodes}|}${node_entry}"
        else
          other_comp_primary_nodes="${other_comp_primary_nodes:+${other_comp_primary_nodes}|}${node_entry}"
        fi
      else
        other_comp_other_nodes="${other_comp_other_nodes:+${other_comp_other_nodes}|}${node_entry}"
      fi
    fi
  }

  # process each node
  while read -r line; do
    node_info=$(parse_node_line_info "$line")
    node_announce_ip=$(printf '%s' "$node_info" | cut -d' ' -f1)
    node_fqdn=$(printf '%s' "$node_info" | cut -d' ' -f2)
    node_port=$(printf '%s' "$node_info" | cut -d' ' -f3)
    node_bus_port=$(printf '%s' "$node_info" | cut -d' ' -f4)
    node_role=$(printf '%s' "$node_info" | cut -d' ' -f5)

    # build node entry based on network mode
    node_entry=$(build_node_entry "$network_mode" "$node_announce_ip" "$node_fqdn" "$node_port" "$node_bus_port")

    # categorize nodes
    categorize_node "$node_entry" "$node_fqdn" "$node_role"
  done << _NODES_EOF_
$cluster_nodes_info
_NODES_EOF_

  echo "current_comp_primary_node: ${current_comp_primary_node}"
  echo "current_comp_primary_fail_node: ${current_comp_primary_fail_node}"
  echo "current_comp_other_nodes: ${current_comp_other_nodes}"
  echo "other_comp_primary_nodes: ${other_comp_primary_nodes}"
  echo "other_comp_primary_fail_nodes: ${other_comp_primary_fail_nodes}"
  echo "other_comp_other_nodes: ${other_comp_other_nodes}"
}

# Note: During rebuild-instance, a new PVC is created without existing data and having the rebuild.flag file.
# Therefore, we must rejoin this instance to the cluster as a secondary node.
is_rebuild_instance() {
  # Early return if rebuild flag doesn't exist
  [ ! -f /data/rebuild.flag ] && return 1

  # Check if nodes.conf exists
  if [ ! -f /data/nodes.conf ]; then
    echo "Rebuild instance detected: nodes.conf missing"
    return 0
  fi

  # Check if nodes.conf contains only one node
  if [ "$(grep -c ':' /data/nodes.conf)" -eq 1 ]; then
    echo "Rebuild instance detected: single node configuration"
    return 0
  fi

  return 1
}

remove_rebuild_instance_flag() {
  if [ -f /data/rebuild.flag ]; then
    rm -f /data/rebuild.flag
    echo "remove rebuild.flag file succeeded!"
  fi
}

# scale out replica of redis cluster shard if needed
scale_redis_cluster_replica() {
  # Waiting for redis-server to start
  check_current_ready_ip="127.0.0.1"
  if [ -n "$redis_announce_host_value" ]; then
    check_current_ready_ip=$redis_announce_host_value
  fi
  if check_redis_server_ready_with_retry "127.0.0.1" "$service_port"; then
    echo "FalkorDB server is ready, continue to scale out replica..."
  else
    echo "FalkorDB server is not ready, exit scale out replica..." >&2
    exit 1
  fi

  if [ -f /data/nodes.conf ]; then
    echo "the nodes.conf file after redis server start:"
    cat /data/nodes.conf
  else
    echo "the nodes.conf file after redis server start is not exist"
  fi

  for target_node_name in $(echo "${CURRENT_SHARD_POD_NAME_LIST}" | tr ',' '\n'); do
     if [ -f /data/rebuild.flag ] && [ "${CURRENT_POD_NAME}" = "${target_node_name}" ]; then
       continue
     fi
     target_node_fqdn=$(get_target_pod_fqdn_from_pod_fqdn_vars "$CURRENT_SHARD_POD_FQDN_LIST" "$target_node_name")
     if is_empty "$target_node_fqdn"; then
       echo "Error: Failed to get target node fqdn from current shard pod fqdn list: $CURRENT_SHARD_POD_FQDN_LIST. Exiting." >&2
       exit 1
     fi
     # get the current component nodes for scale out replica
     get_current_comp_nodes_for_scale_out_replica "$target_node_fqdn" "$service_port"
     if [ $? -eq 0 ]; then
       break
     fi
  done

  # check current_comp_primary_node is empty or not
  if [ -z "$current_comp_primary_node" ]; then
    if is_rebuild_instance; then
      echo "current instance is a rebuild-instance, the current shard primary cannot be empty, please check the cluster status" >&2
      shutdown_redis_server "$service_port"
      exit 1
    fi
    if [ -z "$current_comp_primary_fail_node" ]; then
      echo "current_comp_primary_node is empty, skip scale out replica"
      exit 0
    fi
    # if current_comp_primary_node is empty, use current_comp_primary_fail_node instead
    current_comp_primary_node="$current_comp_primary_fail_node"
  fi

  # primary_node_info value format: cluster_announce_ip#pod_fqdn#endpoint:port@bus_port
  primary_node_info=$(printf '%s' "$current_comp_primary_node" | cut -d'|' -f1)
  primary_node_endpoint_with_port=$(echo "$primary_node_info" | awk -F '@' '{print $1}' | awk -F '#' '{print $3}')
  primary_node_endpoint=$(echo "$primary_node_endpoint_with_port" | awk -F ':' '{print $1}')
  primary_node_port=$(echo "$primary_node_endpoint_with_port" | awk -F ':' '{print $2}')
  primary_node_fqdn=$(echo "$primary_node_info" | awk -F '#' '{print $2}')
  primary_node_bus_port=$(echo "$primary_node_info" | awk -F '@' '{print $2}')
  if contains "$primary_node_fqdn" "$CURRENT_POD_NAME"; then
     echo "Current pod $CURRENT_POD_NAME is primary node, check and correct other primary nodes..."
     check_and_meet_other_primary_nodes "$primary_node_endpoint" "$primary_node_port"
     echo "Node $CURRENT_POD_NAME is already in the cluster, skipping scale out replica..."
     exit 0
  fi
  # if the current pod is not a rebuild-instance and is already in the cluster, skip scale out replica
  if ! is_rebuild_instance && check_node_in_cluster_with_retry "$primary_node_endpoint" "$primary_node_port" "$CURRENT_POD_NAME"; then
    # if current pod is primary node, check the others primary info, if the others primary node info is expired, send cluster meet command again
    echo "Current pod $CURRENT_POD_NAME is a secondary node, check and meet current primary node..."
    check_and_meet_current_primary_node "$primary_node_endpoint" "$primary_node_port" "$primary_node_bus_port"
    echo "Node $CURRENT_POD_NAME is already in the cluster, skipping scale out replica..."
    exit 0
  fi

  # add the current node as a replica of the primary node
  primary_node_cluster_id=$(get_cluster_id_with_retry "$primary_node_endpoint" "$primary_node_port")
  status=$?
  if is_empty "$primary_node_cluster_id" || [ $status -ne 0 ]; then
    echo "Failed to get the cluster id of the primary node $primary_node_endpoint_with_port, sleep 30s for waiting next pod to start" >&2
    sleep 30s
    shutdown_redis_server "$service_port"
    exit 1
  fi
  # current_node_with_port do not use advertised svc and port, because advertised svc and port are not ready when Pod is not Ready.
  current_pod_fqdn=$(get_target_pod_fqdn_from_pod_fqdn_vars "$CURRENT_SHARD_POD_FQDN_LIST" "$CURRENT_POD_NAME")
  if is_rebuild_instance; then
    echo "Current instance is a rebuild-instance, forget node id in the cluster firstly."
    node_id=$(get_cluster_id_with_retry "$primary_node_endpoint" "$primary_node_port" "$current_pod_fqdn")
    if [ -z ${REDIS_DEFAULT_PASSWORD} ]; then
      redis-cli $REDIS_CLI_TLS_CMD -p $service_port --cluster call $primary_node_endpoint_with_port cluster forget ${node_id}
    else
      redis-cli $REDIS_CLI_TLS_CMD -p $service_port --cluster call $primary_node_endpoint_with_port cluster forget ${node_id} -a ${REDIS_DEFAULT_PASSWORD}
    fi
  fi
  current_node_with_port="$current_pod_fqdn:$service_port"
  replicated_output=$(secondary_replicated_to_primary "$current_node_with_port" "$primary_node_endpoint_with_port" "$primary_node_cluster_id")
  status=$?
  if [ $status -ne 0 ] ; then
    if is_rebuild_instance && contains "$replicated_output" "is not empty"; then
      echo "Current instance is a rebuild-instance, but the node already knows other nodes (check with CLUSTER NODES) or contains some key in database 0, shutdown redis server..." >&2
      shutdown_redis_server
      exit 1
    elif contains "$replicated_output" "is not empty"; then
      echo "Replica is not empty, Either the node already knows other nodes (check with CLUSTER NODES) or contains some key in database 0"
    elif contains "$replicated_output" "Not all 16384 slots are covered by nodes"; then
      # shutdown the redis server if the cluster is not fully covered by nodes
      echo "Not all 16384 slots are covered by nodes, shutdown redis server" >&2
      shutdown_redis_server
      exit 1
    else
      echo "Failed to add the node $current_pod_fqdn to the cluster in scale_redis_cluster_replica, Error message: $replicated_output, shutdown redis server" >&2
      shutdown_redis_server "$service_port"
      exit 1
    fi
  fi

  if is_rebuild_instance; then
    echo "replicate the node $current_pod_fqdn to the primary node $primary_node_endpoint_with_port successfully in rebuild-instance, remove rebuild.flag file..."
    remove_rebuild_instance_flag
  fi

  # Hacky: When the entire redis cluster is restarted, a hacky sleep is used to wait for all primaries to enter the restarting state
  sleep_when_ut_mode_false 5

  # cluster meet the primary node until the current node is successfully added to the cluster
  current_primary_met=false
  _other_primary_met=""  # pipe-separated list of already-met node_infos
  while true; do
    all_met=true

    # meet current component primary node if not met yet
    if [ "$current_primary_met" = "false" ]; then
      if scale_out_replica_send_meet "$primary_node_endpoint" "$primary_node_port" "$primary_node_bus_port" "$CURRENT_POD_NAME"; then
        echo "Successfully meet the primary node $primary_node_endpoint_with_port in scale_redis_cluster_replica"
        current_primary_met=true
      else
        echo "Failed to meet current primary node $primary_node_endpoint_with_port"
        all_met=false
      fi
    fi

    # meet the other components primary nodes if not met yet
    for node_info in $(printf '%s' "$other_comp_primary_nodes" | tr '|' '\n'); do
      case "|${_other_primary_met}|" in
        *"|${node_info}|"*) ;; # already met
        *)
          node_endpoint_with_port=$(echo "$node_info" | awk -F '@' '{print $1}' | awk -F '#' '{print $3}')
          node_endpoint=$(echo "$node_endpoint_with_port" | awk -F ':' '{print $1}')
          node_port=$(echo "$node_endpoint_with_port" | awk -F ':' '{print $2}')
          node_bus_port=$(echo "$node_info" | awk -F '@' '{print $2}')

          if scale_out_replica_send_meet "$node_endpoint" "$node_port" "$node_bus_port" "$CURRENT_POD_NAME"; then
            echo "Successfully meet the primary node $node_endpoint_with_port in scale_redis_cluster_replica"
            _other_primary_met="${_other_primary_met:+${_other_primary_met}|}${node_info}"
          else
            echo "Failed to meet the other component primary node $node_endpoint_with_port in scale_redis_cluster_replica" >&2
            all_met=false
          fi
          ;;
      esac
    done

    # If all nodes are met successfully, break the loop
    if [ "$all_met" = "true" ] && [ "$current_primary_met" = "true" ]; then
      echo "All primary nodes have been successfully met"
      break
    fi

    sleep_when_ut_mode_false 3
  done
}

scale_out_replica_send_meet() {
  local node_endpoint_to_meet="$1"
  local node_port_to_meet="$2"
  local node_bus_port_to_meet="$3"
  local node_to_join="$4"

  if check_node_in_cluster "$node_endpoint_to_meet" "$node_port_to_meet" "$node_to_join"; then
    echo "Node $CURRENT_POD_NAME is successfully added to the cluster."
    return 0
  fi

  node_cluster_announce_ip=$(get_cluster_announce_ip_with_retry "$node_endpoint_to_meet" "$node_port_to_meet")
  # send cluster meet command to the target node
  if send_cluster_meet_with_retry "127.0.0.1" "$service_port" "$node_cluster_announce_ip" "$node_port_to_meet" "$node_bus_port_to_meet"; then
    echo "scale out replica meet the node $node_cluster_announce_ip successfully..."
  else
    echo "Failed to meet the node $node_endpoint_to_meet in scale_redis_cluster_replica, shutdown redis server" >&2
    return 1
  fi

  return 0
}

load_redis_template_conf() {
  echo "include $redis_template_conf" >> $redis_real_conf
  # if the file redis_extra_conf exists, include it too
  if [ -f $redis_extra_conf ]; then
    echo "include $redis_extra_conf" >> $redis_real_conf
  fi
}

build_redis_default_accounts() {
  unset_xtrace_when_ut_mode_false
  if ! is_empty "$REDIS_REPL_PASSWORD"; then
    echo "masteruser $REDIS_REPL_USER" >> $redis_real_conf
    echo "masterauth $REDIS_REPL_PASSWORD" >> $redis_real_conf
    echo "user $REDIS_REPL_USER on +psync +replconf +ping >$REDIS_REPL_PASSWORD" >> $redis_acl_file
  fi
  if ! is_empty "$REDIS_DEFAULT_PASSWORD"; then
    echo "protected-mode yes" >> $redis_real_conf
    echo "user default on >$REDIS_DEFAULT_PASSWORD ~* &* +@all " >> $redis_acl_file
  else
    echo "protected-mode no" >> $redis_real_conf
  fi
  set_xtrace_when_ut_mode_false
  echo "aclfile /data/users.acl" >> $redis_real_conf
  echo "build redis default accounts succeeded!"
}

add_extra_falkordb_user_account() {
  if is_empty "$FALKORDB_EXTRA_USER_USERNAME" || is_empty "$FALKORDB_EXTRA_USER_PASSWORD"; then
    echo "No extra FalkorDB user configured, skipping."
    return
  fi

  local acl_rules="$FALKORDB_EXTRA_USER_ACL"
  if is_empty "$acl_rules"; then
    acl_rules="~* +@all"
  fi

  echo "Adding extra FalkorDB user $FALKORDB_EXTRA_USER_USERNAME to ACL file."
  # Remove any existing entry for this user to prevent duplicates
  if [ -f $redis_acl_file ]; then
    sed "/user $FALKORDB_EXTRA_USER_USERNAME on/d" $redis_acl_file > $redis_acl_file_bak && mv $redis_acl_file_bak $redis_acl_file
  fi
  echo "user $FALKORDB_EXTRA_USER_USERNAME on >$FALKORDB_EXTRA_USER_PASSWORD $acl_rules" >> $redis_acl_file
}

rebuild_redis_acl_file() {
  if [ -f $redis_acl_file ]; then
    sed "/user default on/d" $redis_acl_file > $redis_acl_file_bak && mv $redis_acl_file_bak $redis_acl_file
    sed "/user $REDIS_REPL_USER on/d" $redis_acl_file > $redis_acl_file_bak && mv $redis_acl_file_bak $redis_acl_file
    sed "/user $REDIS_SENTINEL_USER on/d" $redis_acl_file > $redis_acl_file_bak && mv $redis_acl_file_bak $redis_acl_file
  else
    touch $redis_acl_file
  fi
}

build_announce_ip_and_port() {
  local announce_host_value=""
  local announce_port_value=""
  # build announce ip and port according to whether the advertised svc is enabled
  if ! is_empty "$redis_announce_host_value" && ! is_empty "$redis_announce_port_value"; then
    echo "redis use advertised svc $redis_announce_host_value:$redis_announce_port_value to announce"
    announce_host_value="$redis_announce_host_value"
    announce_port_value="$redis_announce_port_value"
  elif [ "$FIXED_POD_IP_ENABLED" = "true" ]; then
    echo "redis use fixed pod ip: $CURRENT_POD_IP to announce"
    announce_host_value="$CURRENT_POD_IP"
  else
    current_pod_fqdn=$(get_target_pod_fqdn_from_pod_fqdn_vars "$CURRENT_SHARD_POD_FQDN_LIST" "$CURRENT_POD_NAME")
    if is_empty "$current_pod_fqdn"; then
      echo "Error: Failed to get current pod: $CURRENT_POD_NAME fqdn from current shard pod fqdn list: $CURRENT_SHARD_POD_FQDN_LIST. Exiting."
      exit 1
    fi
    echo "redis use kb pod fqdn $current_pod_fqdn to announce"
    announce_host_value="$current_pod_fqdn"
  fi

  announce_host_value=$(get_announce_hostname_override_or_default "$announce_host_value")
  if ! is_empty "$ANNOUNCE_HOSTNAME_OVERRIDE"; then
    echo "announce hostname override is set, using $announce_host_value for replica announce"
  fi

  {
    if ! is_empty "$announce_port_value"; then
      echo "replica-announce-port $announce_port_value"
    fi
    echo "replica-announce-ip $announce_host_value"
  } >> $redis_real_conf
}

get_target_pod_cluster_announce_hostname() {
  local target_pod_fqdn="$1"
  if ! is_empty "$ANNOUNCE_HOSTNAME_OVERRIDE"; then
    echo "$ANNOUNCE_HOSTNAME_OVERRIDE"
    return
  fi
  echo "$target_pod_fqdn"
}

get_announce_hostname_override_or_default() {
  local default_value="$1"
  if ! is_empty "$ANNOUNCE_HOSTNAME_OVERRIDE"; then
    echo "$ANNOUNCE_HOSTNAME_OVERRIDE"
    return
  fi
  echo "$default_value"
}

build_cluster_announce_info() {
  current_pod_fqdn=$(get_target_pod_fqdn_from_pod_fqdn_vars "$CURRENT_SHARD_POD_FQDN_LIST" "$CURRENT_POD_NAME")
  cluster_announce_hostname_value=$(get_target_pod_cluster_announce_hostname "$current_pod_fqdn")
  if is_empty "$current_pod_fqdn"; then
    echo "Error: Failed to get current pod: $CURRENT_POD_NAME fqdn from current shard pod fqdn list: $CURRENT_SHARD_POD_FQDN_LIST. Exiting."
    exit 1
  fi
  if ! is_empty "$ANNOUNCE_HOSTNAME_OVERRIDE"; then
    echo "announce hostname override is set, using $cluster_announce_hostname_value for cluster announce"
  fi
  # build announce ip and port according to whether the advertised svc is enabled
  if ! is_empty "$redis_announce_host_value" && ! is_empty "$redis_announce_port_value" && ! is_empty "$redis_announce_bus_port_value"; then
    echo "redis cluster use advertised svc $redis_announce_host_value:$redis_announce_port_value@$redis_announce_bus_port_value to announce"
    {
      echo "cluster-announce-ip $redis_announce_host_value"
      echo "cluster-announce-bus-port $redis_announce_bus_port_value"
      echo "cluster-announce-hostname $cluster_announce_hostname_value"
      echo "cluster-preferred-endpoint-type ip"
      if [ "$TLS_ENABLED" = "true" ]; then
        echo "cluster-announce-tls-port $redis_announce_port_value"
        echo "cluster-announce-port 0"
      else
        echo "cluster-announce-port $redis_announce_port_value"
      fi
    } >> $redis_real_conf
  elif [ "$FIXED_POD_IP_ENABLED" = "true" ]; then
    echo "redis cluster use fixed pod ip: $CURRENT_POD_IP to announce"
    {
      echo "cluster-announce-ip $CURRENT_POD_IP"
      echo "cluster-announce-hostname $cluster_announce_hostname_value"
      echo "cluster-preferred-endpoint-type ip"
    } >> $redis_real_conf
  else
    echo "redis cluster use pod fqdn $cluster_announce_hostname_value to announce"
    {
      echo "cluster-announce-ip $CURRENT_POD_IP"
      echo "cluster-announce-hostname $cluster_announce_hostname_value"
      echo "cluster-preferred-endpoint-type hostname"
    } >> $redis_real_conf
  fi
}

build_redis_cluster_service_port() {
  if ! is_empty "$SERVICE_PORT"; then
    service_port=$SERVICE_PORT
  fi
  if ! is_empty "$CLUSTER_BUS_PORT"; then
    cluster_bus_port=$CLUSTER_BUS_PORT
  fi
  if [ "$TLS_ENABLED" = "true" ]; then
    echo "tls-port $service_port" >> $redis_real_conf
  else
    echo "port $service_port" >> $redis_real_conf
  fi
  echo "cluster-port $cluster_bus_port" >> $redis_real_conf
}

parse_redis_cluster_shard_announce_addr() {
  # The value format of CURRENT_SHARD_ADVERTISED_PORT and CURRENT_SHARD_ADVERTISED_BUS_PORT are "pod1Svc:advertisedPort1,pod2Svc:advertisedPort2,..."
  if is_empty "$CURRENT_SHARD_ADVERTISED_PORT" || is_empty "$CURRENT_SHARD_ADVERTISED_BUS_PORT"; then
    echo "Environment variable CURRENT_SHARD_ADVERTISED_PORT and CURRENT_SHARD_ADVERTISED_BUS_PORT not found. Ignoring."
    # if redis cluster is in host network mode, use the host ip and port as the announce ip and port
    if ! is_empty "${REDIS_CLUSTER_HOST_NETWORK_PORT}" && ! is_empty "${REDIS_CLUSTER_HOST_NETWORK_BUS_PORT}"; then
      echo "redis cluster server is in host network mode, use the host ip:$CURRENT_POD_HOST_IP and port:$REDIS_CLUSTER_HOST_NETWORK_PORT, bus port:$REDIS_CLUSTER_HOST_NETWORK_BUS_PORT as the announce ip and port."
      redis_announce_port_value="$REDIS_CLUSTER_HOST_NETWORK_PORT"
      redis_announce_bus_port_value="$REDIS_CLUSTER_HOST_NETWORK_BUS_PORT"
      redis_announce_host_value="$CURRENT_POD_HOST_IP"
    fi
    return 0
  fi

  local pod_name="$CURRENT_POD_NAME"
  local port
  local bus_port
  svc_and_port=$(parse_advertised_svc_and_port "$pod_name" "$CURRENT_SHARD_ADVERTISED_PORT" "true")
  status=$?
  if [ "$status" -ne 0 ] || is_empty "$svc_and_port"; then
    echo "Exiting due to error in CURRENT_SHARD_ADVERTISED_PORT."
    exit 1
  fi

  bus_port=$(parse_advertised_svc_and_port "$pod_name" "$CURRENT_SHARD_ADVERTISED_BUS_PORT")
  status=$?
  if [ "$status" -ne 0 ] || is_empty "$bus_port"; then
    echo "Exiting due to error in CURRENT_SHARD_ADVERTISED_BUS_PORT."
    exit 1
  fi
  redis_announce_port_value="${svc_and_port#*:}"
  redis_announce_bus_port_value="$bus_port"
  svc_name=${svc_and_port%:*}
  lb_host=$(extract_lb_host_by_svc_name "${svc_name}")
  if [ -n "$lb_host" ]; then
    echo "Found load balancer host for svcName '$svc_name', value is '$lb_host'."
    redis_announce_host_value="$lb_host"
    redis_announce_port_value="${SERVICE_PORT:-6379}"
    redis_announce_bus_port_value="16379"
  else
    redis_announce_host_value="$CURRENT_POD_HOST_IP"
  fi
}

start_redis_server() {
    module_path="/var/lib/falkordb/bin"
    exec_cmd="exec redis-server /etc/redis/redis.conf"
    if [ -f ${module_path}/falkordb.so ]; then
        exec_cmd="$exec_cmd --loadmodule ${module_path}/falkordb.so ${FALKORDB_ARGS}"
    fi
    echo "Starting falkordb server cmd: $exec_cmd"
    eval "$exec_cmd"
}

# build redis cluster configuration redis.conf
build_redis_conf() {
  load_redis_template_conf
  build_redis_cluster_service_port
  build_announce_ip_and_port
  build_cluster_announce_info
  rebuild_redis_acl_file
  build_redis_default_accounts
  add_extra_falkordb_user_account
}

# This is magic for shellspec ut framework.
# Sometime, functions are defined in a single shell script.
# You will want to test it. but you do not want to run the script.
# When included from shellspec, __SOURCED__ variable defined and script
# end here. The script path is assigned to the __SOURCED__ variable.
${__SOURCED__:+false} : || return 0

init_environment
load_redis_cluster_common_utils
parse_redis_cluster_shard_announce_addr
build_redis_conf
# TODO: move to memberJoin action in the future
scale_redis_cluster_replica &
start_redis_server
